package addingtwo;
import java.util.ArrayList;

import java.util.Scanner;		
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JOptionPane;

/**
 *
 * @author Limoolindokuhle
 */
public class Lindokuhle_Part1 {
	private static String userNumber;
	private static int getProductByCode(ArrayList<Task>task,String Task_Name) {
		for(int i=0;i<task.size();i++) {
			if(task.get(i).getTask_Name().compareTo(Task_Name)==0) {
				return(i);
			}
		}
		return -1;
	}
	/**
     * @param args the command line arguments		     
     * */
	public static void main(String[] args) 
    	{
		    // Registration Page
		    Scanner input=new Scanner(System.in);
		    String Rpassword = null;
		    String firstname, lastname, Rusername;

	        System.out.println("************************************");
		    System.out.println("**********Registration Page*********");
		    System.out.println("************************************");
		    System.out.print("First Name: ");
		    String firstName = input.nextLine();
		    System.out.print("Last Name: ");
		    String lastName = input.nextLine();
		    System.out.println("Username should contains an underscore and is no \n" +
		            "more than 5 characters long");
		    System.out.print("Username: ");
		    Rusername = input.nextLine();
		    Pattern pattern = Pattern.compile("^[A-Za-z0-9_]{1,5}$"); // username should contain an underscore and be 5 characters or less
		    Matcher matcher = pattern.matcher(Rusername);
		    if (matcher.matches()) 
		    {
		        System.out.println("Username usefully captured");
		    } else 
		    {
		        System.out.print("Try again once: ");
		        Rusername = input.nextLine();
		        if (matcher.matches()) 
		        {
		            System.out.println("The information is incorrect.");
		        } else 
		        {
		            System.out.println("Username usefully captured");
		        }
		    }
		    int attempts = 0;

		    while (attempts < 5) {

			System.out.print("Enter a password: ");
			Rpassword = input.nextLine();

			boolean hasNumber = false;
			boolean hasSpecialChar = false;
			boolean hasCapitalLetter = false;

			if (Rpassword.length() < 8) {
				System.out.println("Password must be at least 8 characters long."
                                        +"\nContain at least 1 number."
                                        +"\nAt least 1 special character."
                                        +"\n1 capital letter.");
			} else {
				for (int i = 0; i < Rpassword.length(); i++) {
					char ch = Rpassword.charAt(i);

					if (Character.isDigit(ch)) {
						hasNumber = true;
					} else if (!Character.isLetter(ch)) {
						hasSpecialChar = true;
					} else if (Character.isUpperCase(ch)) {
						hasCapitalLetter = true;
					}
				}

				if (!hasNumber) {
					System.out.println("Password must contain at least 1 number.");
				} else if (!hasSpecialChar) {
					System.out.println("Password must contain at least 1 special character.");
				} else if (!hasCapitalLetter) {
					System.out.println("Password must contain at least 1 capital letter.");
				} else {
					System.out.println("Password is valid.");
					break;
				}
			}

			attempts++;
		}

		if (attempts >= 5) {
			System.out.println("Sorry, you can try again later.");
			System.exit(0);
		}
		
		    
	
		    // Login Page
		    System.out.println("\n=============================="
		    		+"\n==========Login Page=========="
		    		+"\n*Enter your details to confirm the registration*");
		    System.out.print("Username: ");
		    String loginUsername = input.nextLine();
		    System.out.print("Password: ");
		    String loginPassword = input.nextLine();
		    if (loginUsername.equals(Rusername) && loginPassword.equals(Rpassword)) {
		        System.out.println("Welcome " + firstName + " " + lastName + ", it is great to see you.");
		    } else 
		    {
		        System.out.println("Incorrect data");
		        System.out.print("Please enter again.\nUsername: ");
		        loginUsername = input.nextLine();
		        System.out.print("Password: ");
		        loginPassword = input.nextLine();
		        if (!(loginUsername.equals(Rusername) && loginPassword.equals(Rpassword))) {
		            System.out.println("Incorrect data");
		            System.exit(0);
		        } else 
		        {
		            System.out.println("Welcome " + firstName + " " + lastName + ",�Welcome to EasyKanban�.");
		        }
		    }

		    System.out.print("Enter (1) to continue or (4) to exit: ");
		    int number=input.nextInt();
		    if(number==1)
		    {
		    	ArrayList<Task>task=new ArrayList<Task>();
		    	String name,Userdetails1,Userdetails2,taskname;
		    	String description;
		    	String details;
		    	int tasks;
		    	while(number!=3)
		    	{
		    		System.out.println("=========================================="
		    				+"\n==========WELCOME TO EAZYKHANBAN=========="
		    				+"\n=========================================="
		    				+"\n(1) Add task"
		    				+"\n(2) Show report"
		    				+"\n(3) Quit"
		    				+"\nChoose a number: ");
		    		number=input.nextInt();
		    		switch(number) 
		    		{
		    		case 1:
		    		{
		    			input.next();
		    			System.out.print("Enter then number of tasks you want to ADD: ");
			    		tasks=input.nextInt();
			    		for (int i=0;i<tasks;i++) 
			    		{
			    			System.out.print("\nTask " + (i) + ": Enter the task Name: ");
				    		name=input.next();
				    		System.out.println();
				    	    System.out.print("Enter a text (max 50 characters): ");
				            String text = input.nextLine();
				            if(text.length()<=50)
				            {
				                System.out.println("Your text didn't reach the limit");
				            }
				            else 
				            {
				                System.out.println("Over the limit!!!!!!!!."+"Try again.");
				                text=input.nextLine();
				                if(text.length()>=50)
				                {
				                    System.out.println("Your text didn't reach the limit.");
				                }else{
				                    System.out.println("Plese try again later.");
				                    System.exit(0);
				                }
				            }
				            System.out.print("Enter your name: ");
				            String userfirstname=input.nextLine();
				            System.out.print("Enter your last name: ");
				            String userlastname=input.nextLine();
				            System.out.println("To Do"
				            		+"\nDoing"+
				            		"\nDone"
				            		+"\nPick the task status: ");
				            int status=input.nextInt();
				            if(status==1) 
				            {
				            	System.out.println("To Do!.");
				            }else if(status==2)
				            {
				            	System.out.println("Doing!.");
				            }else {
				            	System.out.println("Done!.");
				            }
				            
				    	    Task newTask=new Task(name, text, userlastname);
				    	    task.add(newTask);
				    	    JOptionPane.showInputDialog("\nTask added!!."
				    	    		+"\n Task name: "+name
				    	    		+"\nTask numer: "+tasks
				    	    		+"\nTask description: "+text
				    	    		+"\nDeveloper details: "+userfirstname+" "+userlastname
				    	    		+"\nTask status: "+status);
				    	    
				    	    
				    	       	    
			    		}
		    		}
		    		
		    		break;
		    		
		    		case 2:
		    		{
		    			
		    			System.out.println("Coming soon."
		    					+"\nThis option is still under development!!!."
		    					+"\nTHANK YOU!!!.");
		    		}
		    		case 3:
		    		{
		    			System.exit(0);
		    		}
		    		
		    		
		    	}
		    }
		    }
		 }
	}
			