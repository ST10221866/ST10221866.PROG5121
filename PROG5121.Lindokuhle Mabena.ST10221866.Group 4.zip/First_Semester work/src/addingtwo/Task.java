package addingtwo;

public class Task 
{
	private String Task_Name;
	private String Task_Description;
	private String Developer_Details; 
	
	public Task()
	{
		this.Task_Name="";
		this.Task_Description="";
		this.Developer_Details="";
	}
	public Task(String Task_Name,String Task_Description,String Developer_Details) 
	{
		this.Task_Name=Task_Name;
		this.Task_Description=Task_Description;
		this.Developer_Details=Developer_Details;
	}
	public String getTask_Name() {
		return Task_Name;
	}
	public void setTask_Name(String task_Name) {
		Task_Name = task_Name;
	}
	public String getTask_Description() {
		return Task_Description;
	}
	public void setTask_Description(String task_Description) {
		Task_Description = task_Description;
	}
	public String getDeveloper_Details() {
		return Developer_Details;
	}
	public void setDeveloper_Details(String developer_Details) {
		Developer_Details = developer_Details;
	}
	@Override
	public String toString() {
		return "Task Name: "+this.Task_Name
				+"\nTask description: "+this.Task_Description
				+"\nDeveloper details: "+this.Developer_Details;
		
	}
	
	
}
